<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('movies', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('external_id')->unique();
            $table->string('title');
            $table->string('poster');
            $table->date('release_date');
            $table->json('genres');
            $table->float('rating')->nullable(true)->default(0);
            $table->string('original_language');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('movies');
    }
};
